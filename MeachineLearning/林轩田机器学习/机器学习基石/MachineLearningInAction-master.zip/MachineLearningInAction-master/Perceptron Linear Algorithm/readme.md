## Perceptron Linear Algorithm

- PLA.ipynb : PLA + Pocket PLA

- PLA.py : PLA

- Pocket_PLA.py : Pocket PLA
