## Softmax Linear Classifier

- Softmax.ipynb

- CIFAR-10数据集下载地址：

  - 链接：https://pan.baidu.com/s/1iZPwt72j-EpVUbLKgEpYMQ

  - 密码：vy1e
