# MachineLearningInAction

## 1. Perceptron Linear Algorithm

- includes:
  - PLA.ipynb
  - PLA.py
  - Pocket_PLA.py

## 2. kNN

- includes:
  - KNN.ipynb

## 3. SVM

- includes:
  - SVM.ipynb
