# First GAN Program by PyTorch

- GAN_1.py

- GAN_1.ipynb
